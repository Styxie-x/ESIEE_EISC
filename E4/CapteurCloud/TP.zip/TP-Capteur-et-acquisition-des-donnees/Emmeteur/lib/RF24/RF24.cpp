/*
 Copyright (C) 2011 J. Coliz <maniacbug@ymail.com>

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 version 2 as published by the Free Software Foundation.
 */

#include "nRF24L01.h"
#include "RF24_config.h"
#include "RF24.h"

/****************************************************************************/

void RF24::csn(bool mode)
{

#if defined (RF24_TINY)
	if (ce_pin != csn_pin) {
		digitalWrite(csn_pin,mode);
	} 
	else {
		if (mode == HIGH) {
			PORTB |= (1<<PINB2);  	// SCK->CSN HIGH
			delayMicroseconds(100); // allow csn to settle.
		} 
		else {
			PORTB &= ~(1<<PINB2);	// SCK->CSN LOW
			delayMicroseconds(11);  // allow csn to settle
		}
	}
	// Return, CSN toggle complete
	return;
	
#elif defined(ARDUINO) && !defined (RF24_SPI_TRANSACTIONS)
	// Minimum ideal SPI bus speed is 2x data rate
	// If we assume 2Mbs data rate and 16Mhz clock, a
	// divider of 4 is the minimum we want.
	// CLK:BUS 8Mhz:2Mhz, 16Mhz:4Mhz, or 20Mhz:5Mhz
	
      #if !defined (SOFTSPI)	
		_SPI.setBitOrder(MSBFIRST);
		_SPI.setDataMode(SPI_MODE0);
		_SPI.setClockDivider(SPI_CLOCK_DIV2);
      #endif
#elif defined (RF24_RPi)
      if(!mode)
	    _SPI.chipSelect(csn_pin);
#endif

#if !defined (RF24_LINUX)
	digitalWrite(csn_pin,mode);
	delayMicroseconds(5);
#endif

}

/****************************************************************************/

void RF24::ce(bool level)
{
  //Allow for 3-pin use on ATTiny
  if (ce_pin != csn_pin) digitalWrite(ce_pin,level);
}

/****************************************************************************/

  inline void RF24::beginTransaction() {
    #if defined (RF24_SPI_TRANSACTIONS)
    _SPI.beginTransaction(SPISettings(RF24_SPI_SPEED, MSBFIRST, SPI_MODE0));
	#endif
    csn(LOW);
  }

/****************************************************************************/

  inline void RF24::endTransaction() {
    csn(HIGH);
	#if defined (RF24_SPI_TRANSACTIONS)
    _SPI.endTransaction();
	#endif
  }

/****************************************************************************/

uint8_t RF24::read_register(uint8_t reg, uint8_t* buf, uint8_t len)
{
  uint8_t status;

  #if defined (RF24_LINUX)
  beginTransaction(); //configures the spi settings for RPi, locks mutex and setting csn low
  uint8_t * prx = spi_rxbuff;
  uint8_t * ptx = spi_txbuff;
  uint8_t size = len + 1; // Add register value to transmit buffer

  *ptx++ = ( R_REGISTER | ( REGISTER_MASK & reg ) );

  while (len--){ *ptx++ = NOP; } // Dummy operation, just for reading
  
  _SPI.transfernb( (char *) spi_txbuff, (char *) spi_rxbuff, size);
  
  status = *prx++; // status is 1st byte of receive buffer

  // decrement before to skip status byte
  while ( --size ){ *buf++ = *prx++; } 
  endTransaction(); //unlocks mutex and setting csn high

#else

  beginTransaction();
  status = _SPI.transfer( R_REGISTER | ( REGISTER_MASK & reg ) );
  while ( len-- ){
    *buf++ = _SPI.transfer(0xff);
  }
  endTransaction();

#endif

  return status;
}

/****************************************************************************/

uint8_t RF24::read_register(uint8_t reg)
{
  uint8_t result;
  
  #if defined (RF24_LINUX)
	
  beginTransaction();
  
  uint8_t * prx = spi_rxbuff;
  uint8_t * ptx = spi_txbuff;	
  *ptx++ = ( R_REGISTER | ( REGISTER_MASK & reg ) );
  *ptx++ = NOP ; // Dummy operation, just for reading
  
  _SPI.transfernb( (char *) spi_txbuff, (char *) spi_rxbuff, 2);
  result = *++prx;   // result is 2nd byte of receive buffer
  
  endTransaction();
  #else

  beginTransaction();
  _SPI.transfer( R_REGISTER | ( REGISTER_MASK & reg ) );
  result = _SPI.transfer(0xff);
  endTransaction();

  #endif

  return result;
}

/****************************************************************************/

uint8_t RF24::write_register(uint8_t reg, const uint8_t* buf, uint8_t len)
{
  uint8_t status;

  #if defined (RF24_LINUX) 
  beginTransaction();
  uint8_t * prx = spi_rxbuff;
  uint8_t * ptx = spi_txbuff;
  uint8_t size = len + 1; // Add register value to transmit buffer

  *ptx++ = ( W_REGISTER | ( REGISTER_MASK & reg ) );
  while ( len-- )
    *ptx++ = *buf++;
  
  _SPI.transfernb( (char *) spi_txbuff, (char *) spi_rxbuff, size);
  status = *prx; // status is 1st byte of receive buffer
  endTransaction();
  #else

  beginTransaction();
  status = _SPI.transfer( W_REGISTER | ( REGISTER_MASK & reg ) );
  while ( len-- )
    _SPI.transfer(*buf++);
  endTransaction();

  #endif

  return status;
}

/****************************************************************************/

uint8_t RF24::write_register(uint8_t reg, uint8_t value)
{
  uint8_t status;

  IF_SERIAL_DEBUG(printf_P(PSTR("write_register(%02x,%02x)\r\n"),reg,value));

  #if defined (RF24_LINUX)
    beginTransaction();
	uint8_t * prx = spi_rxbuff;
	uint8_t * ptx = spi_txbuff;
	*ptx++ = ( W_REGISTER | ( REGISTER_MASK & reg ) );
	*ptx = value ;	
  	
	_SPI.transfernb( (char *) spi_txbuff, (char *) spi_rxbuff, 2);
	status = *prx++; // status is 1st byte of receive buffer
	endTransaction();
  #else

  beginTransaction();
  status = _SPI.transfer( W_REGISTER | ( REGISTER_MASK & reg ) );
  _SPI.transfer(value);
  endTransaction();

  #endif

  return status;
}

/****************************************************************************/

uint8_t RF24::write_payload(const void* buf, uint8_t data_len, const uint8_t writeType)
{
  uint8_t status;
  const uint8_t* current = reinterpret_cast<const uint8_t*>(buf);

   data_len = rf24_min(data_len, payload_size);
   uint8_t blank_len = dynamic_payloads_enabled ? 0 : payload_size - data_len;
  
  //printf("[Writing %u bytes %u blanks]",data_len,blank_len);
  IF_SERIAL_DEBUG( printf("[Writing %u bytes %u blanks]\n",data_len,blank_len); );
  
 #if defined (RF24_LINUX)
	beginTransaction();
	uint8_t * prx = spi_rxbuff;
	uint8_t * ptx = spi_txbuff;
    uint8_t size;
	size = data_len + blank_len + 1 ; // Add register value to transmit buffer

	*ptx++ =  writeType;
    while ( data_len-- )
      *ptx++ =  *current++;
    while ( blank_len-- )
	  *ptx++ =  0;
	
	_SPI.transfernb( (char *) spi_txbuff, (char *) spi_rxbuff, size);
	status = *prx; // status is 1st byte of receive buffer
	endTransaction();

  #else

  beginTransaction();
  status = _SPI.transfer( writeType );
  while ( data_len-- ) {
    _SPI.transfer(*current++);
  }
  while ( blank_len-- ) {
    _SPI.transfer(0);
  }  
  endTransaction();

  #endif

  return status;
}

/****************************************************************************/

uint8_t RF24::read_payload(void* buf, uint8_t data_len)
{
  uint8_t status;
  uint8_t* current = reinterpret_cast<uint8_t*>(buf);

  if(data_len > payload_size) data_len = payload_size;
  uint8_t blank_len = dynamic_payloads_enabled ? 0 : payload_size - data_len;
  
  //printf("[Reading %u bytes %u blanks]",data_len,blank_len);

  IF_SERIAL_DEBUG( printf("[Reading %u bytes %u blanks]\n",data_len,blank_len); );
  
  #if defined (RF24_LINUX)
	beginTransaction();
	uint8_t * prx = spi_rxbuff;
	uint8_t * ptx = spi_txbuff;
    uint8_t size;
    size = data_len + blank_len + 1; // Add register value to transmit buffer

	*ptx++ =  R_RX_PAYLOAD;
	while(--size) 
		*ptx++ = NOP;
		
	size = data_len + blank_len + 1; // Size has been lost during while, re affect
	
	_SPI.transfernb( (char *) spi_txbuff, (char *) spi_rxbuff, size);
	
	status = *prx++; // 1st byte is status	
    
	while ( --data_len ) // Decrement before to skip 1st status byte
        *current++ = *prx++;
		
	*current = *prx;
	endTransaction();
  #else

  beginTransaction();
  status = _SPI.transfer( R_RX_PAYLOAD );
  while ( data_len-- ) {
    *current++ = _SPI.transfer(0xFF);
  }
  while ( blank_len-- ) {
    _SPI.transfer(0xff);
  }
  endTransaction();

  #endif

  return status;
}

/****************************************************************************/

uint8_t RF24::flush_rx(void)
{
  return spiTrans( FLUSH_RX );
}

/****************************************************************************/

uint8_t RF24::flush_tx(void)
{
  return spiTrans( FLUSH_TX );
}

/****************************************************************************/

uint8_t RF24::spiTrans(uint8_t cmd){

  uint8_t status;
  
  beginTransaction();
  status = _SPI.transfer( cmd );
  endTransaction();
  
  return status;
}

/****************************************************************************/

uint8_t RF24::get_status(void)
{
  return spiTrans(NOP);
}

/****************************************************************************/
#if !defined (MINIMAL)
void RF24::print_status(uint8_t status)
{
  printf_P(PSTR("STATUS\t\t = 0x%02x\t[RX_DR=%x TX_DS=%x MAX_RT=%x RX_P_NO=%x TX_FULL=%x]\r\n"),
           status,
           (status & _BV(RX_DR))?1:0,
           (status & _BV(TX_DS))?1:0,
           (status & _BV(MAX_RT))?1:0,
           ((status >> RX_P_NO) & 0b111),
           (status & _BV(TX_FULL))?1:0
          );
}

/****************************************************************************/

void RF24::print_observe_tx(uint8_t value)
{
  printf_P(PSTR("OBSERVE_TX=%02x: POLS_CNT=%x ARC_CNT=%x\r\n"),
           value,
           (value >> PLOS_CNT) & 0b1111,
           (value >> ARC_CNT) & 0b1111
          );
}

/****************************************************************************/

void RF24::print_byte_register(const char* name, uint8_t reg, uint8_t qty)
{
  //char extra_tab = strlen_P(name) < 8 ? '\t' : 0;
  //printf_P(PSTR(PRIPSTR"\t%c ="),name,extra_tab);
  #if defined (RF24_LINUX)
    printf("%s\t =", name);
  #else
    printf_P(PSTR(PRIPSTR"\t ="),name);
  #endif
  while (qty--)
    printf_P(PSTR(" 0x%02x"),read_register(reg++));
  //printf_P(PSTR("\r\n"));
}

/****************************************************************************/

void RF24::print_address_register(const char* name, uint8_t reg, uint8_t qty)
{

  #if defined (RF24_LINUX)
    printf("%s\t =",name);
  #else
    printf_P(PSTR(PRIPSTR"\t ="),name);
  #endif
  while (qty--)
  {
    uint8_t buffer[addr_width];
    read_register(reg++,buffer,sizeof buffer);

    printf_P(PSTR(" 0x"));
    uint8_t* bufptr = buffer + sizeof buffer;
    while( --bufptr >= buffer )
      printf_P(PSTR("%02x"),*bufptr);
  }

  printf_P(PSTR("\r\n"));
}
#endif
/****************************************************************************/

RF24::RF24(uint8_t _cepin, uint8_t _cspin):
  ce_pin(_cepin), csn_pin(_cspin), p_variant(false),
  payload_size(32), dynamic_payloads_enabled(false), addr_width(5)//,pipe0_reading_address(0)
{
  pipe0_reading_address[0]=0;
}

/****************************************************************************/

#if defined (RF24_LINUX) && !defined (MRAA)//RPi constructor
RF24::RF24(uint8_t _cepin, uint8_t _cspin, uint32_t _spi_speed):
  ce_pin(_cepin),csn_pin(_cspin),spi_speed(_spi_speed),p_variant(false), payload_size(32), dynamic_payloads_enabled(false),addr_width(5)//,pipe0_reading_address(0) 
{
  pipe0_reading_address[0]=0;
}
#endif

/****************************************************************************/

void RF24::setChannel(uint8_t channel)
{
  const uint8_t max_channel = 125;
  write_register(RF_CH,rf24_min(channel,max_channel));
}

uint8_t RF24::getChannel()
{
  
  return read_register(RF_CH);
}
/****************************************************************************/

void RF24::setPayloadSize(uint8_t size)
{
  payload_size = rf24_min(size,32);
}

/****************************************************************************/

uint8_t RF24::getPayloadSize(void)
{
  return payload_size;
}

/****************************************************************************/

#if !defined (MINIMAL)

static const char rf24_addr_w_e_str_0[] PROGMEM = "Illegal";
static const char rf24_addr_w_e_str_1[] PROGMEM = "3 Bytes";
static const char rf24_addr_w_e_str_2[] PROGMEM = "4 Bytes";
static const char rf24_addr_w_e_str_3[] PROGMEM = "5 Bytes";
static const char * const rf24_addr_w_e_str_P[] PROGMEM = {
  rf24_addr_w_e_str_0,
  rf24_addr_w_e_str_1,
  rf24_addr_w_e_str_2,
  rf24_addr_w_e_str_3,
};

static const char rf24_datarate_e_str_0[] PROGMEM = "1MBPS";
static const char rf24_datarate_e_str_1[] PROGMEM = "2MBPS";
static const char rf24_datarate_e_str_2[] PROGMEM = "250KBPS";
static const char * const rf24_datarate_e_str_P[] PROGMEM = {
  rf24_datarate_e_str_0,
  rf24_datarate_e_str_1,
  rf24_datarate_e_str_2,
};
static const char rf24_model_e_str_0[] PROGMEM = "nRF24L01";
static const char rf24_model_e_str_1[] PROGMEM = "nRF24L01+";
static const char * const rf24_model_e_str_P[] PROGMEM = {
  rf24_model_e_str_0,
  rf24_model_e_str_1,
};
static const char rf24_crclength_e_str_0[] PROGMEM = "Disabled";
static const char rf24_crclength_e_str_1[] PROGMEM = "8 bits";
static const char rf24_crclength_e_str_2[] PROGMEM = "16 bits" ;
static const char * const rf24_crclength_e_str_P[] PROGMEM = {
  rf24_crclength_e_str_0,
  rf24_crclength_e_str_1,
  rf24_crclength_e_str_2,
};
static const char rf24_pa_dbm_e_str_0[] PROGMEM = "PA_MIN (-18dBm)";
static const char rf24_pa_dbm_e_str_1[] PROGMEM = "PA_LOW (-12dBm)";
static const char rf24_pa_dbm_e_str_2[] PROGMEM = "PA_HIGH (-6dBm)";
static const char rf24_pa_dbm_e_str_3[] PROGMEM = "PA_MAX (0dBm)";
static const char * const rf24_pa_dbm_e_str_P[] PROGMEM = {
  rf24_pa_dbm_e_str_0,
  rf24_pa_dbm_e_str_1,
  rf24_pa_dbm_e_str_2,
  rf24_pa_dbm_e_str_3,
};

static const char rf24_retransmit_delay_e_str_0[] PROGMEM = "250µs";
static const char rf24_retransmit_delay_e_str_1[] PROGMEM = "500µs";
static const char rf24_retransmit_delay_e_str_2[] PROGMEM = "750µs";
static const char rf24_retransmit_delay_e_str_3[] PROGMEM = "1000µs";
static const char rf24_retransmit_delay_e_str_4[] PROGMEM = "1250µs";
static const char rf24_retransmit_delay_e_str_5[] PROGMEM = "1500µs";
static const char rf24_retransmit_delay_e_str_6[] PROGMEM = "1750µs";
static const char rf24_retransmit_delay_e_str_7[] PROGMEM = "2000µs";
static const char rf24_retransmit_delay_e_str_8[] PROGMEM = "2250µs";
static const char rf24_retransmit_delay_e_str_9[] PROGMEM = "2500µs";
static const char rf24_retransmit_delay_e_str_10[] PROGMEM = "2750µs";
static const char rf24_retransmit_delay_e_str_11[] PROGMEM = "3000µs";
static const char rf24_retransmit_delay_e_str_12[] PROGMEM = "3250µs";
static const char rf24_retransmit_delay_e_str_13[] PROGMEM = "3500µs";
static const char rf24_retransmit_delay_e_str_14[] PROGMEM = "3750µs";
static const char rf24_retransmit_delay_e_str_15[] PROGMEM = "4000µs";
static const char * const rf24_retransmit_delay_e_str_P[] PROGMEM = {
  rf24_retransmit_delay_e_str_0,
  rf24_retransmit_delay_e_str_1,
  rf24_retransmit_delay_e_str_2,
  rf24_retransmit_delay_e_str_3,
  rf24_retransmit_delay_e_str_4,
  rf24_retransmit_delay_e_str_5,
  rf24_retransmit_delay_e_str_6,
  rf24_retransmit_delay_e_str_7,
  rf24_retransmit_delay_e_str_8,
  rf24_retransmit_delay_e_str_9,
  rf24_retransmit_delay_e_str_10,
  rf24_retransmit_delay_e_str_11,
  rf24_retransmit_delay_e_str_12,
  rf24_retransmit_delay_e_str_13,
  rf24_retransmit_delay_e_str_14,
  rf24_retransmit_delay_e_str_15,
};

static const char rf24_retransmit_count_e_str_0[] PROGMEM = "Transmit disabled";
static const char rf24_retransmit_count_e_str_1[] PROGMEM = "1";
static const char rf24_retransmit_count_e_str_2[] PROGMEM = "2";
static const char rf24_retransmit_count_e_str_3[] PROGMEM = "3";
static const char rf24_retransmit_count_e_str_4[] PROGMEM = "4";
static const char rf24_retransmit_count_e_str_5[] PROGMEM = "5";
static const char rf24_retransmit_count_e_str_6[] PROGMEM = "6";
static const char rf24_retransmit_count_e_str_7[] PROGMEM = "7";
static const char rf24_retransmit_count_e_str_8[] PROGMEM = "8";
static const char rf24_retransmit_count_e_str_9[] PROGMEM = "9";
static const char rf24_retransmit_count_e_str_10[] PROGMEM = "10";
static const char rf24_retransmit_count_e_str_11[] PROGMEM = "11";
static const char rf24_retransmit_count_e_str_12[] PROGMEM = "12";
static const char rf24_retransmit_count_e_str_13[] PROGMEM = "13";
static const char rf24_retransmit_count_e_str_14[] PROGMEM = "14";
static const char rf24_retransmit_count_e_str_15[] PROGMEM = "15";
static const char * const rf24_retransmit_count_e_str_P[] PROGMEM = {
  rf24_retransmit_count_e_str_0,
  rf24_retransmit_count_e_str_1,
  rf24_retransmit_count_e_str_2,
  rf24_retransmit_count_e_str_3,
  rf24_retransmit_count_e_str_4,
  rf24_retransmit_count_e_str_5,
  rf24_retransmit_count_e_str_6,
  rf24_retransmit_count_e_str_7,
  rf24_retransmit_count_e_str_8,
  rf24_retransmit_count_e_str_9,
  rf24_retransmit_count_e_str_10,
  rf24_retransmit_count_e_str_11,
  rf24_retransmit_count_e_str_12,
  rf24_retransmit_count_e_str_13,
  rf24_retransmit_count_e_str_14,
  rf24_retransmit_count_e_str_15,
};

#if defined (RF24_LINUX)
static const char rf24_csn_e_str_0[] = "CE0 (PI Hardware Driven)";
static const char rf24_csn_e_str_1[] = "CE1 (PI Hardware Driven)";
static const char rf24_csn_e_str_2[] = "CE2 (PI Hardware Driven)";
static const char rf24_csn_e_str_3[] = "Custom GPIO Software Driven";
static const char * const rf24_csn_e_str_P[] = {
  rf24_csn_e_str_0,
  rf24_csn_e_str_1,
  rf24_csn_e_str_2,
  rf24_csn_e_str_3,
};
#endif

void RF24::printDetails(void)
{

#if defined (RF24_RPi)
  printf("================ SPI Configuration ================\n" );
  if (csn_pin < BCM2835_SPI_CS_NONE ){
    printf("CSN Pin  \t = %s\n",rf24_csn_e_str_P[csn_pin]);
  }else{
    printf("CSN Pin  \t = Custom GPIO%d%s\n", csn_pin,
    csn_pin==RPI_V2_GPIO_P1_26 ? " (CE1) Software Driven" : "" );
  }
  printf("CE Pin  \t = Custom GPIO%d\n", ce_pin );
  printf("Clock Speed\t = " );
	switch (spi_speed)
	{
		case BCM2835_SPI_SPEED_64MHZ : printf("64 Mhz");	break ;
		case BCM2835_SPI_SPEED_32MHZ : printf("32 Mhz");	break ;
		case BCM2835_SPI_SPEED_16MHZ : printf("16 Mhz");	break ;
		case BCM2835_SPI_SPEED_8MHZ  : printf("8 Mhz");	break ;
		case BCM2835_SPI_SPEED_4MHZ  : printf("4 Mhz");	break ;
		case BCM2835_SPI_SPEED_2MHZ  : printf("2 Mhz");	break ;
		case BCM2835_SPI_SPEED_1MHZ  : printf("1 Mhz");	break ;
		case BCM2835_SPI_SPEED_512KHZ: printf("512 KHz");	break ;
		case BCM2835_SPI_SPEED_256KHZ: printf("256 KHz");	break ;
		case BCM2835_SPI_SPEED_128KHZ: printf("128 KHz");	break ;
		case BCM2835_SPI_SPEED_64KHZ : printf("64 KHz");	break ;
		case BCM2835_SPI_SPEED_32KHZ : printf("32 KHz");	break ;
		case BCM2835_SPI_SPEED_16KHZ : printf("16 KHz");	break ;
		case BCM2835_SPI_SPEED_8KHZ  : printf("8 KHz");	break ;
		default : printf("8 Mhz");	break ;
	}
	 
#endif //Linux
	
	//printf("\r\n******* Firmware Parameters : Register MAP Values*******\r\n");


 
  printf("\r\n" );
  printf_P(PSTR("Model\t\t = " PRIPSTR "\r\n"),pgm_read_word(&rf24_model_e_str_P[isPVariant()]));

  
  print_status(get_status());

  print_byte_register(PSTR("SETUP_AW"),SETUP_AW); 
  printf_P(PSTR("\t[Address Width = " PRIPSTR "]\r\n"), pgm_read_word(&rf24_addr_w_e_str_P[getAddrWidth()]));
  print_address_register(PSTR("RX_ADDR_P0"),RX_ADDR_P0);
  print_byte_register(PSTR("RX_PW_P0"),RX_PW_P0);
  
  print_address_register(PSTR("\r\nRX_ADDR_P1"),RX_ADDR_P1);
  print_byte_register(PSTR("RX_PW_P1"),RX_PW_P1);
  
  print_byte_register(PSTR("\r\nRX_ADDR_P2"),RX_ADDR_P2);
  print_byte_register(PSTR("\r\nRX_PW_P2"),RX_PW_P2);
  
  print_byte_register(PSTR("\r\nRX_ADDR_P3"),RX_ADDR_P3);
  print_byte_register(PSTR("\r\nRX_PW_P3"),RX_PW_P3);
  
  print_byte_register(PSTR("\r\nRX_ADDR_P4"),RX_ADDR_P4);
  print_byte_register(PSTR("\r\nRX_PW_P4"),RX_PW_P4);
  
  print_byte_register(PSTR("\r\nRX_ADDR_P5"),RX_ADDR_P5);
  print_byte_register(PSTR("\r\nRX_PW_P5"),RX_PW_P5);
  
  //print_byte_register(PSTR("RX_ADDR_P2-5"),RX_ADDR_P2,4);
  
  print_address_register(PSTR("\r\nTX_ADDR\t"),TX_ADDR);

  //print_byte_register(PSTR("RX_PW_P0-6"),RX_PW_P0,6);
  
  print_byte_register(PSTR("SETUP_RETR"),SETUP_RETR);
  printf_P(PSTR("\t[Retransmit Delay = " PRIPSTR " "),  pgm_read_word(&rf24_retransmit_delay_e_str_P[getRetransmitDelay()]));
  printf_P(PSTR("Retransmit Count = " PRIPSTR "]\r\n"),  pgm_read_word(&rf24_retransmit_count_e_str_P[getRetransmitCount()]));
  
  print_byte_register(PSTR("EN_AA\t"),EN_AA);
  printf_P(PSTR("\t[ENAA_P0=%x ENAA_P1=%x ENAA_P2=%x ENAA_P3=%x ENAA_P4=%x ENAA_P5=%x]\r\n"), (read_register(EN_AA) & _BV(ENAA_P0))?1:0, (read_register(EN_AA) & _BV(ENAA_P1))?1:0, (read_register(EN_AA) & _BV(ENAA_P2))?1:0, (read_register(EN_AA) & _BV(ENAA_P3))?1:0, (read_register(EN_AA) & _BV(ENAA_P4))?1:0, (read_register(EN_AA) & _BV(ENAA_P5))?1:0 );
  
  
  print_byte_register(PSTR("EN_RXADDR"),EN_RXADDR);
  printf_P(PSTR("\t[ERX_P0=%x ERX_P1=%x ERX_P2=%x ERX_P3=%x ERX_P4=%x ERX_P5=%x]\r\n"), (read_register(EN_RXADDR) & _BV(ERX_P0))?1:0, (read_register(EN_RXADDR) & _BV(ERX_P1))?1:0, (read_register(EN_RXADDR) & _BV(ERX_P2))?1:0, (read_register(EN_RXADDR) & _BV(ERX_P3))?1:0, (read_register(EN_RXADDR) & _BV(ERX_P4))?1:0, (read_register(EN_RXADDR) & _BV(ERX_P5))?1:0 );
     
   
  print_byte_register(PSTR("RF_CH\t"),RF_CH);
  printf_P(PSTR("\t[For Information : RF_CH_Frequency = %dMHZ]\r\n"),(2400+ (int) read_register(RF_CH)));
   
  print_byte_register(PSTR("RF_SETUP"),RF_SETUP);
  printf_P(PSTR("\t[Data Rate = " PRIPSTR " "),pgm_read_word(&rf24_datarate_e_str_P[getDataRate()]));
  printf_P(PSTR("PA Power = " PRIPSTR "]\r\n"),  pgm_read_word(&rf24_pa_dbm_e_str_P[getPALevel()]));
  
  print_byte_register(PSTR("CONFIG\t"),CONFIG);
  printf_P(PSTR("\t[CRC Length = " PRIPSTR "]\r\n"),pgm_read_word(&rf24_crclength_e_str_P[getCRCLength()]));
  
  print_byte_register(PSTR("DYNP\tD"),DYNPD);
  printf_P(PSTR("\t[DPL_P0=%x DPL_P1=%x DPL_P2=%x DPL_P3=%x DPL_P4=%x DPL_P5=%x]\r\n"), (read_register(DYNPD) & _BV(DPL_P0))?1:0, (read_register(DYNPD) & _BV(DPL_P1))?1:0, (read_register(DYNPD) & _BV(DPL_P2))?1:0, (read_register(DYNPD) & _BV(DPL_P3))?1:0, (read_register(DYNPD) & _BV(DPL_P4))?1:0, (read_register(DYNPD) & _BV(DPL_P5))?1:0 );
      
  
  print_byte_register(PSTR("FEATURE\t"),FEATURE);
  printf_P(PSTR("\t[EN_DPL=%x EN_ACK_PAY=%x EN_DYN_ACK=%x]\r\n"), (read_register(FEATURE) & _BV(EN_DPL))?1:0, (read_register(FEATURE) & _BV(EN_ACK_PAY))?1:0, (read_register(FEATURE) & _BV(EN_DYN_ACK))?1:0 );
       
}

#endif

/*********************************************************************************************/

void RF24::printStatistics(void)
{

printf("\r\n******* Statistics*******\r\n");

print_status(get_status());

print_byte_register(PSTR("FIFO_STAT"),FIFO_STATUS);
printf_P(PSTR("\t[TX_FULL=%x TX_EMPTY=%x RX_FULL=%x RX_EMPTY=%x]\r\n"), (read_register(FIFO_STATUS) & _BV(FIFO_FULL))?1:0, (read_register(FIFO_STATUS) & _BV(TX_EMPTY))?1:0, (read_register(FIFO_STATUS) & _BV(RX_FULL))?1:0, (read_register(FIFO_STATUS) & _BV(RX_EMPTY))?1:0 );

print_byte_register(PSTR("OBSERVE_TX"),OBSERVE_TX);
printf_P(PSTR("\t[PLOS_CNT=%x ARC_CNT=%d]\r\n"), ((int)(read_register(OBSERVE_TX) & 0b11110000) >> 4), (int)(read_register(OBSERVE_TX) & 0b00001111) );
   	
}


void RF24::FastresestNRF24(void)
{

	uint8_t addr0[5] = {0x7e, 0x7e, 0x7e, 0x7e, 0x7e};
	uint8_t addr1[5] = {0xc2, 0xc2, 0xc2, 0xc2, 0xc2};


	//printf("\r\n******* Reset Firmware Parameters *******\r\n");

	write_register( CONFIG, 0b00001000 ) ;
        
    write_register( EN_AA, 0b00111111 ) ;

	  
    write_register( EN_RXADDR, 0b00000011 ) ;
    	  	
    write_register( SETUP_AW, 0b00000011 ) ;
	
	write_register( SETUP_RETR, 0b00000011 ) ;

	  		
	write_register( RF_CH, 0b00000010 ) ;

	
	write_register( RF_SETUP, 0b00001110 ) ;

	
	write_register( NRF_STATUS, 0b00001110 ) ;

	  
    write_register( OBSERVE_TX, 0b00000000 ) ;

	  	
    write_register( CD, 0b00000000 ) ;

	
	write_register( TX_ADDR, addr0, 5) ;

	
    write_register( RX_ADDR_P0, addr0, 5) ;

	
	write_register( RX_ADDR_P1, addr1, 5) ;

	
	write_register( RX_ADDR_P2, 0xc3 ) ;

	
	write_register( RX_ADDR_P3, 0xc4 ) ;

	  
    write_register( RX_ADDR_P4, 0xc5 ) ;

	  	
    write_register( RX_ADDR_P5, 0xc6 ) ;

	 		
	write_register( RX_PW_P0, 0b00000000 ) ;

	
	write_register( RX_PW_P1, 0b00000000 ) ;

	
	write_register( RX_PW_P2, 0b00000000 ) ;

	  
    write_register( RX_PW_P3, 0b00000000 ) ;


    write_register( RX_PW_P4, 0b00000000 ) ;

	
	write_register( RX_PW_P5, 0b00000000 ) ;


	write_register( FIFO_STATUS, 0b00010001 ) ;

	
	write_register( DYNPD, 0b00000000 ) ;

	write_register( FEATURE, 0b00000000 ) ;
	
	
}


void RF24::resestNRF24(void)
{

	uint8_t addr0[5] = {0x7e, 0x7e, 0x7e, 0x7e, 0x7e};
	uint8_t addr1[5] = {0xc2, 0xc2, 0xc2, 0xc2, 0xc2};


	//printf("\r\n******* Reset Firmware Parameters *******\r\n");

	write_register( CONFIG, 0b00001000 ) ;
        //printf("Register CONFIG : OK\r\n");
	printf("\r\n" );
        printf("Register CONFIG " );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
        delay(200);
	
        
        write_register( EN_AA, 0b00111111 ) ;
	//printf("Register EN_AA : OK\r\n");
        
        printf("Register EN_AA ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	  
    write_register( EN_RXADDR, 0b00000011 ) ;
    //printf("Register EN_RXADDR : OK\r\n");
    printf("Register EN_RXADDR ");
    delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	  	
    write_register( SETUP_AW, 0b00000011 ) ;
	//printf("Register SETUP_AW : OK\r\n");
        printf("Register SETUP_AW ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( SETUP_RETR, 0b00000011 ) ;
	//printf("Register SETUP_RETR : OK\r\n");
        printf("Register SETUP_RETR ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	  		
	write_register( RF_CH, 0b00000010 ) ;
	//printf("Register RF_CH : OK\r\n");
        printf("Register RF_CH ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( RF_SETUP, 0b00001110 ) ;
	//printf("Register RF_SETUP : OK\r\n");
        printf("Register RF_SETUP ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( NRF_STATUS, 0b00001110 ) ;
	//printf("Register NRF_STATUS : OK\r\n");
        printf("Register NRF_STATUS ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	  
    write_register( OBSERVE_TX, 0b00000000 ) ;
    //printf("Register OBSERVE_TX : OK\r\n");
    printf("Register OBSERVE_TX ");
    delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	  	
    write_register( CD, 0b00000000 ) ;
	//printf("Register CD : OK\r\n");
        printf("Register CD ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( TX_ADDR, addr0, 5) ;
	//printf("Register TX_ADDR : OK\r\n");
        printf("Register TX_ADDR ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
    write_register( RX_ADDR_P0, addr0, 5) ;
	//printf("Register RX_ADDR_P0 : OK\r\n");
        printf("Register RX_ADDR_P0 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( RX_ADDR_P1, addr1, 5) ;
	//printf("Register RX_ADDR_P1 : OK\r\n");
        printf("Register RX_ADDR_P1 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( RX_ADDR_P2, 0xc3 ) ;
	//printf("Register RX_ADDR_P2 : OK\r\n");
        printf("Register RX_ADDR_P2 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( RX_ADDR_P3, 0xc4 ) ;
	//printf("Register RX_ADDR_P3 : OK\r\n");
        printf("Register RX_ADDR_P3 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	  
    write_register( RX_ADDR_P4, 0xc5 ) ;
    //printf("Register RX_ADDR_P4 : OK\r\n");
     printf("Register RX_ADDR_P4 ");
    delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	  	
    write_register( RX_ADDR_P5, 0xc6 ) ;
	//printf("Register RX_ADDR_P5 : OK\r\n");
        printf("Register RX_ADDR_P5 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	 		
	write_register( RX_PW_P0, 0b00000000 ) ;
	//printf("Register RX_PW_P0 : OK\r\n");
        printf("Register RX_PW_P0 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( RX_PW_P1, 0b00000000 ) ;
	//printf("Register RX_PW_P1 : OK\r\n");
        printf("Register RX_PW_P1 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( RX_PW_P2, 0b00000000 ) ;
	//printf("Register RX_PW_P2 : OK\r\n");
        printf("Register RX_PW_P2 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	  
    write_register( RX_PW_P3, 0b00000000 ) ;
    //printf("Register RX_PW_P3 : OK\r\n");
    printf("Register RX_PW_P3 ");
    delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );

    write_register( RX_PW_P4, 0b00000000 ) ;
	//printf("Register RX_PW_P4 : OK\r\n");
        printf("Register RX_PW_P4 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( RX_PW_P5, 0b00000000 ) ;
	//printf("Register RX_PW_P5 : OK\r\n");
        printf("Register RX_PW_P5 ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );

	write_register( FIFO_STATUS, 0b00010001 ) ;
	//printf("Register FIFO_STATUS : OK\r\n");
        printf("Register FIFO_STATUS ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( DYNPD, 0b00000000 ) ;
	//printf("Register DYNPD : OK\r\n");
        printf("Register DYNPD ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
	
	write_register( FEATURE, 0b00000000 ) ;
	//printf("Register FEATURE : OK\r\n");
        printf("Register FEATURE ");
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("." );
        delay(200);
        printf("OK\r\n" );
		
	
}

/****************************************************************************/

bool RF24::begin(void)
{

  uint8_t setup=0;

  #if defined (RF24_LINUX)

	SPI();
    
	#if defined (MRAA)
	  GPIO();	
	  gpio.begin(ce_pin,csn_pin);	
	#endif
	

	switch(csn_pin){     //Ensure valid hardware CS pin
	  case 0: break;
	  case 1: break;
	  // Allow BCM2835 enums for RPi
	  case 8: csn_pin = 0; break;
	  case 7: csn_pin = 1; break;
	  default: csn_pin = 0; break;
	}	
	
    _SPI.begin(csn_pin);

	pinMode(ce_pin,OUTPUT);
	ce(LOW);    

	delay(100);
  
  #elif defined(LITTLEWIRE)
    pinMode(csn_pin,OUTPUT);
    _SPI.begin();
    csn(HIGH);
  #else
    // Initialize pins
    if (ce_pin != csn_pin) pinMode(ce_pin,OUTPUT);  
  
    #if ! defined(LITTLEWIRE)
      if (ce_pin != csn_pin)
    #endif
        pinMode(csn_pin,OUTPUT);
    
    _SPI.begin();
    ce(LOW);
  	csn(HIGH);
  	#if defined (__ARDUINO_X86__)
		delay(100);
  	#endif
  #endif //Linux

  // Must allow the radio time to settle else configuration bits will not necessarily stick.
  // This is actually only required following power up but some settling time also appears to
  // be required after resets too. For full coverage, we'll always assume the worst.
  // Enabling 16b CRC is by far the most obvious case if the wrong timing is used - or skipped.
  // Technically we require 4.5ms + 14us as a worst case. We'll just call it 5ms for good measure.
  // WARNING: Delay is based on P-variant whereby non-P *may* require different timing.
  delay( 5 ) ;

  // Reset CONFIG and enable 16-bit CRC.
  write_register( CONFIG, 0b00001100 ) ;

  // Set 1500uS (minimum for 32B payload in ESB@250KBPS) timeouts, to make testing a little easier
  // WARNING: If this is ever lowered, either 250KBS mode with AA is broken or maximum packet
  // sizes must never be used. See documentation for a more complete explanation.
  setRetries(5,15);

  // Reset value is MAX
  //setPALevel( RF24_PA_MAX ) ;

  // check for connected module and if this is a p nRF24l01 variant
  //
  if( setDataRate( RF24_250KBPS ) )
  {
    p_variant = true ;
  }
  /*setup = read_register(RF_SETUP);
  if( setup == 0b00001110 )     // register default for nRF24L01P
  {
    p_variant = true ;
  }*/
  
  // Then set the data rate to the slowest (and most reliable) speed supported by all
  // hardware.
  setDataRate( RF24_1MBPS ) ;

  // Initialize CRC and request 2-byte (16bit) CRC
  //setCRCLength( RF24_CRC_16 ) ;

  // Disable dynamic payloads, to match dynamic_payloads_enabled setting - Reset value is 0
  toggle_features();
  write_register(FEATURE,0 );
  write_register(DYNPD,0);

  // Reset current status
  // Notice reset and flush is the last thing we do
  write_register(NRF_STATUS,_BV(RX_DR) | _BV(TX_DS) | _BV(MAX_RT) );

  // Set up default configuration.  Callers can always change it later.
  // This channel should be universally safe and not bleed over into adjacent
  // spectrum.
  setChannel(76);

  // Flush buffers
  flush_rx();
  flush_tx();

  powerUp(); //Power up by default when begin() is called

  // Enable PTX, do not write CE high so radio will remain in standby I mode ( 130us max to transition to RX or TX instead of 1500us from powerUp )
  // PTX should use only 22uA of power
  write_register(CONFIG, ( read_register(CONFIG) ) & ~_BV(PRIM_RX) );

  // if setup is 0 or ff then there was no response from module
  return ( setup != 0 && setup != 0xff );
}


bool RF24::NRF24Initialization(void)
{

  uint8_t setup=0;

  #if defined (RF24_LINUX)

	SPI();
    
	#if defined (MRAA)
	  GPIO();	
	  gpio.begin(ce_pin,csn_pin);	
	#endif
	

	switch(csn_pin){     //Ensure valid hardware CS pin
	  case 0: break;
	  case 1: break;
	  // Allow BCM2835 enums for RPi
	  case 8: csn_pin = 0; break;
	  case 7: csn_pin = 1; break;
	  default: csn_pin = 0; break;
	}	
	
    _SPI.begin(csn_pin);

	pinMode(ce_pin,OUTPUT);
	ce(LOW);    

	delay(100);
  
  #elif defined(LITTLEWIRE)
    pinMode(csn_pin,OUTPUT);
    _SPI.begin();
    csn(HIGH);
  #else
    // Initialize pins
    if (ce_pin != csn_pin) pinMode(ce_pin,OUTPUT);  
  
    #if ! defined(LITTLEWIRE)
      if (ce_pin != csn_pin)
    #endif
        pinMode(csn_pin,OUTPUT);
    
    _SPI.begin();
    ce(LOW);
  	csn(HIGH);
  	#if defined (__ARDUINO_X86__)
		delay(100);
  	#endif
  #endif //Linux

  // Must allow the radio time to settle else configuration bits will not necessarily stick.
  // This is actually only required following power up but some settling time also appears to
  // be required after resets too. For full coverage, we'll always assume the worst.
  // Enabling 16b CRC is by far the most obvious case if the wrong timing is used - or skipped.
  // Technically we require 4.5ms + 14us as a worst case. We'll just call it 5ms for good measure.
  // WARNING: Delay is based on P-variant whereby non-P *may* require different timing.
  delay( 5 ) ;

  toggle_features();
  
  // Flush buffers
  flush_rx();
  flush_tx();

  powerUp(); //Power up by default when NRF2Initialization is called

  // if setup is 0 or ff then there was no response from module
  return ( setup != 0 && setup != 0xff );
}

/****************************************************************************/

void RF24::startListening(void)
{
 #if !defined (RF24_TINY) && ! defined(LITTLEWIRE)
  powerUp();
 #endif
  write_register(CONFIG, read_register(CONFIG) | _BV(PRIM_RX));
  write_register(NRF_STATUS, _BV(RX_DR) | _BV(TX_DS) | _BV(MAX_RT) );
  ce(HIGH);
  // Restore the pipe0 adddress, if exists
  if (pipe0_reading_address[0] > 0){
    write_register(RX_ADDR_P0, pipe0_reading_address, addr_width);	
  }else{
	closeReadingPipe(0);
  }

  // Flush buffers
  //flush_rx();
  if(read_register(FEATURE) & _BV(EN_ACK_PAY)){
	flush_tx();
  }

  // Go!
  //delayMicroseconds(100);
}

/****************************************************************************/
static const uint8_t child_pipe_enable[] PROGMEM =
{
  ERX_P0, ERX_P1, ERX_P2, ERX_P3, ERX_P4, ERX_P5
};

void RF24::stopListening(void)
{  
  ce(LOW);

  delayMicroseconds(txRxDelay);
  
  if(read_register(FEATURE) & _BV(EN_ACK_PAY)){
    delayMicroseconds(txRxDelay); //200
	flush_tx();
  }
  //flush_rx();
  write_register(CONFIG, ( read_register(CONFIG) ) & ~_BV(PRIM_RX) );
 
  #if defined (RF24_TINY) || defined (LITTLEWIRE)
  // for 3 pins solution TX mode is only left with additonal powerDown/powerUp cycle
  if (ce_pin == csn_pin) {
    powerDown();
	powerUp();
  }
  #endif
  write_register(EN_RXADDR,read_register(EN_RXADDR) | _BV(pgm_read_byte(&child_pipe_enable[0]))); // Enable RX on pipe0
  
  //delayMicroseconds(100);

}

/****************************************************************************/

void RF24::powerDown(void)
{
  ce(LOW); // Guarantee CE is low on powerDown
  write_register(CONFIG,read_register(CONFIG) & ~_BV(PWR_UP));
}

/****************************************************************************/

//Power up now. Radio will not power down unless instructed by MCU for config changes etc.
void RF24::powerUp(void)
{
   uint8_t cfg = read_register(CONFIG);

   // if not powered up then power up and wait for the radio to initialize
   if (!(cfg & _BV(PWR_UP))){
      write_register(CONFIG,read_register(CONFIG) | _BV(PWR_UP));

      // For nRF24L01+ to go from power down mode to TX or RX mode it must first pass through stand-by mode.
	  // There must be a delay of Tpd2stby (see Table 16.) after the nRF24L01+ leaves power down mode before
	  // the CEis set high. - Tpd2stby can be up to 5ms per the 1.0 datasheet
      delay(5);
   }
}

/******************************************************************/
#if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
void RF24::errNotify(){
	#if defined (SERIAL_DEBUG) || defined (RF24_LINUX)
	  printf_P(PSTR("RF24 HARDWARE FAIL: Radio not responding, verify pin connections, wiring, etc.\r\n"));
	#endif
	#if defined (FAILURE_HANDLING)
	failureDetected = 1;
	#else
	delay(5000);
	#endif
}
#endif
/******************************************************************/

//Similar to the previous write, clears the interrupt flags
bool RF24::write( const void* buf, uint8_t len, const bool multicast )
{
	//Start Writing
	startFastWrite(buf,len,multicast);

	//Wait until complete or failed
	#if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
		uint32_t timer = millis();
	#endif 
	
	while( ! ( get_status()  & ( _BV(TX_DS) | _BV(MAX_RT) ))) { 
		#if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
			if(millis() - timer > 85){			
				errNotify();
				#if defined (FAILURE_HANDLING)
				  return 0;		
				#else
				  delay(100);
				#endif
			}
		#endif
	}
    
	ce(LOW);

	uint8_t status = write_register(NRF_STATUS,_BV(RX_DR) | _BV(TX_DS) | _BV(MAX_RT) );

  //Max retries exceeded
  if( status & _BV(MAX_RT)){
  	flush_tx(); //Only going to be 1 packet int the FIFO at a time using this method, so just flush
  	return 0;
  }
	//TX OK 1 or 0
  return 1;
}

bool RF24::write( const void* buf, uint8_t len ){
	return write(buf,len,0);
}
/****************************************************************************/

//For general use, the interrupt flags are not important to clear
bool RF24::writeBlocking( const void* buf, uint8_t len, uint32_t timeout )
{
	//Block until the FIFO is NOT full.
	//Keep track of the MAX retries and set auto-retry if seeing failures
	//This way the FIFO will fill up and allow blocking until packets go through
	//The radio will auto-clear everything in the FIFO as long as CE remains high

	uint32_t timer = millis();							  //Get the time that the payload transmission started

	while( ( get_status()  & ( _BV(TX_FULL) ))) {		  //Blocking only if FIFO is full. This will loop and block until TX is successful or timeout

		if( get_status() & _BV(MAX_RT)){					  //If MAX Retries have been reached
			reUseTX();										  //Set re-transmit and clear the MAX_RT interrupt flag
			if(millis() - timer > timeout){ return 0; }		  //If this payload has exceeded the user-defined timeout, exit and return 0
		}
		#if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
			if(millis() - timer > (timeout+85) ){			
				errNotify();
				#if defined (FAILURE_HANDLING)
				return 0;			
                #endif				
			}
		#endif

  	}

  	//Start Writing
	startFastWrite(buf,len,0);								  //Write the payload if a buffer is clear

	return 1;												  //Return 1 to indicate successful transmission
}

/****************************************************************************/

void RF24::reUseTX(){
		write_register(NRF_STATUS,_BV(MAX_RT) );			  //Clear max retry flag
		spiTrans( REUSE_TX_PL );
		ce(LOW);										  //Re-Transfer packet
		ce(HIGH);
}

/****************************************************************************/

bool RF24::writeFast( const void* buf, uint8_t len, const bool multicast )
{
	//Block until the FIFO is NOT full.
	//Keep track of the MAX retries and set auto-retry if seeing failures
	//Return 0 so the user can control the retrys and set a timer or failure counter if required
	//The radio will auto-clear everything in the FIFO as long as CE remains high

	#if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
		uint32_t timer = millis();
	#endif
	
	while( ( get_status()  & ( _BV(TX_FULL) ))) {			  //Blocking only if FIFO is full. This will loop and block until TX is successful or fail

		if( get_status() & _BV(MAX_RT)){
			//reUseTX();										  //Set re-transmit
			write_register(NRF_STATUS,_BV(MAX_RT) );			  //Clear max retry flag
			return 0;										  //Return 0. The previous payload has been retransmitted
															  //From the user perspective, if you get a 0, just keep trying to send the same payload
		}
		#if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
			if(millis() - timer > 85 ){			
				errNotify();
				#if defined (FAILURE_HANDLING)
				return 0;							
				#endif
			}
		#endif
  	}
		     //Start Writing
	startFastWrite(buf,len,multicast);

	return 1;
}

bool RF24::writeFast( const void* buf, uint8_t len ){
	return writeFast(buf,len,0);
}

/****************************************************************************/

//Per the documentation, we want to set PTX Mode when not listening. Then all we do is write data and set CE high
//In this mode, if we can keep the FIFO buffers loaded, packets will transmit immediately (no 130us delay)
//Otherwise we enter Standby-II mode, which is still faster than standby mode
//Also, we remove the need to keep writing the config register over and over and delaying for 150 us each time if sending a stream of data

void RF24::startFastWrite( const void* buf, uint8_t len, const bool multicast, bool startTx){ //TMRh20

	//write_payload( buf,len);
	write_payload( buf, len,multicast ? W_TX_PAYLOAD_NO_ACK : W_TX_PAYLOAD ) ;
	if(startTx){
		ce(HIGH);
	}

}

/****************************************************************************/

//Added the original startWrite back in so users can still use interrupts, ack payloads, etc
//Allows the library to pass all tests
void RF24::startWrite( const void* buf, uint8_t len, const bool multicast ){

  // Send the payload

  //write_payload( buf, len );
  write_payload( buf, len,multicast? W_TX_PAYLOAD_NO_ACK : W_TX_PAYLOAD ) ;
  ce(HIGH);
  #if defined(CORE_TEENSY) || !defined(ARDUINO) || defined (RF24_BBB) || defined (RF24_DUE)
	delayMicroseconds(10);
  #endif
  ce(LOW);


}

/****************************************************************************/

bool RF24::rxFifoFull(){
	return read_register(FIFO_STATUS) & _BV(RX_FULL);
}
/****************************************************************************/

bool RF24::txStandBy(){

    #if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
		uint32_t timeout = millis();
	#endif
	while( ! (read_register(FIFO_STATUS) & _BV(TX_EMPTY)) ){
		if( get_status() & _BV(MAX_RT)){
			write_register(NRF_STATUS,_BV(MAX_RT) );
			ce(LOW);
			flush_tx();    //Non blocking, flush the data
			return 0;
		}
		#if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
			if( millis() - timeout > 85){
				errNotify();
				#if defined (FAILURE_HANDLING)
				return 0;	
				#endif
			}
		#endif
	}

	ce(LOW);			   //Set STANDBY-I mode
	return 1;
}

/****************************************************************************/

bool RF24::txStandBy(uint32_t timeout, bool startTx){

    if(startTx){
	  stopListening();
	  ce(HIGH);
	}
	uint32_t start = millis();

	while( ! (read_register(FIFO_STATUS) & _BV(TX_EMPTY)) ){
		if( get_status() & _BV(MAX_RT)){
			write_register(NRF_STATUS,_BV(MAX_RT) );
				ce(LOW);										  //Set re-transmit
				ce(HIGH);
				if(millis() - start >= timeout){
					ce(LOW); flush_tx(); return 0;
				}
		}
		#if defined (FAILURE_HANDLING) || defined (RF24_LINUX)
			if( millis() - start > (timeout+85)){
				errNotify();
				#if defined (FAILURE_HANDLING)
				return 0;	
				#endif
			}
		#endif
	}

	
	ce(LOW);				   //Set STANDBY-I mode
	return 1;

}

/****************************************************************************/

void RF24::maskIRQ(bool tx, bool fail, bool rx){

	write_register(CONFIG, ( read_register(CONFIG) ) | fail << MASK_MAX_RT | tx << MASK_TX_DS | rx << MASK_RX_DR  );
}

/****************************************************************************/

uint8_t RF24::getDynamicPayloadSize(void)
{
  uint8_t result = 0;

  #if defined (RF24_LINUX)  
  spi_txbuff[0] = R_RX_PL_WID;
  spi_rxbuff[1] = 0xff;
  beginTransaction();
  _SPI.transfernb( (char *) spi_txbuff, (char *) spi_rxbuff, 2);
  result = spi_rxbuff[1];  
  endTransaction();
  #else
  beginTransaction();
  _SPI.transfer( R_RX_PL_WID );
  result = _SPI.transfer(0xff);
  endTransaction();
  #endif

  if(result > 32) { flush_rx(); delay(2); return 0; }
  return result;
}

/****************************************************************************/

bool RF24::available(void)
{
  return available(NULL);
}

/****************************************************************************/

bool RF24::available(uint8_t* pipe_num)
{
  if (!( read_register(FIFO_STATUS) & _BV(RX_EMPTY) )){

    // If the caller wants the pipe number, include that
    if ( pipe_num ){
	  uint8_t status = get_status();
      *pipe_num = ( status >> RX_P_NO ) & 0b111;
  	}
  	return 1;
  }


  return 0;


}

/****************************************************************************/

void RF24::read( void* buf, uint8_t len ){

  // Fetch the payload
  read_payload( buf, len );

  //Clear the two possible interrupt flags with one command
  write_register(NRF_STATUS,_BV(RX_DR) | _BV(MAX_RT) | _BV(TX_DS) );

}

/****************************************************************************/

void RF24::whatHappened(bool& tx_ok,bool& tx_fail,bool& rx_ready)
{
  // Read the status & reset the status in one easy call
  // Or is that such a good idea?
  uint8_t status = write_register(NRF_STATUS,_BV(RX_DR) | _BV(TX_DS) | _BV(MAX_RT) );

  // Report to the user what happened
  tx_ok = status & _BV(TX_DS);
  tx_fail = status & _BV(MAX_RT);
  rx_ready = status & _BV(RX_DR);
}

/****************************************************************************/

void RF24::openWritingPipe(uint64_t value)
{
  // Note that AVR 8-bit uC's store this LSB first, and the NRF24L01(+)
  // expects it LSB first too, so we're good.

  write_register(RX_ADDR_P0, reinterpret_cast<uint8_t*>(&value), addr_width);
  write_register(TX_ADDR, reinterpret_cast<uint8_t*>(&value), addr_width);
  
  
  //const uint8_t max_payload_size = 32;
  //write_register(RX_PW_P0,rf24_min(payload_size,max_payload_size));
  write_register(RX_PW_P0,payload_size);
}

/****************************************************************************/
void RF24::openWritingPipe(const uint8_t *address)
{
  // Note that AVR 8-bit uC's store this LSB first, and the NRF24L01(+)
  // expects it LSB first too, so we're good.

  write_register(RX_ADDR_P0,address, addr_width);
  write_register(TX_ADDR, address, addr_width);

  //const uint8_t max_payload_size = 32;
  //write_register(RX_PW_P0,rf24_min(payload_size,max_payload_size));
  write_register(RX_PW_P0,payload_size);
}

/****************************************************************************/
static const uint8_t child_pipe[] PROGMEM =
{
  RX_ADDR_P0, RX_ADDR_P1, RX_ADDR_P2, RX_ADDR_P3, RX_ADDR_P4, RX_ADDR_P5
};
static const uint8_t child_payload_size[] PROGMEM =
{
  RX_PW_P0, RX_PW_P1, RX_PW_P2, RX_PW_P3, RX_PW_P4, RX_PW_P5
};


void RF24::openReadingPipe(uint8_t child, uint64_t address)
{
  // If this is pipe 0, cache the address.  This is needed because
  // openWritingPipe() will overwrite the pipe 0 address, so
  // startListening() will have to restore it.
  if (child == 0){
    memcpy(pipe0_reading_address,&address,addr_width);
  }

  if (child <= 6)
  {
    // For pipes 2-5, only write the LSB
    if ( child < 2 )
      write_register(pgm_read_byte(&child_pipe[child]), reinterpret_cast<const uint8_t*>(&address), addr_width);
    else
      write_register(pgm_read_byte(&child_pipe[child]), reinterpret_cast<const uint8_t*>(&address), 1);

    write_register(pgm_read_byte(&child_payload_size[child]),payload_size);

    // Note it would be more efficient to set all of the bits for all open
    // pipes at once.  However, I thought it would make the calling code
    // more simple to do it this way.
    write_register(EN_RXADDR,read_register(EN_RXADDR) | _BV(pgm_read_byte(&child_pipe_enable[child])));
  }
}

/****************************************************************************/
void RF24::setAddressWidth(uint8_t a_width){

	if(a_width -= 2){
		write_register(SETUP_AW,a_width%4);
		addr_width = (a_width%4) + 2;
	}

}

/****************************************************************************/

void RF24::openReadingPipe(uint8_t child, const uint8_t *address)
{
  // If this is pipe 0, cache the address.  This is needed because
  // openWritingPipe() will overwrite the pipe 0 address, so
  // startListening() will have to restore it.
  if (child == 0){
    memcpy(pipe0_reading_address,address,addr_width);
  }
  if (child <= 6)
  {
    // For pipes 2-5, only write the LSB
    if ( child < 2 ){
      write_register(pgm_read_byte(&child_pipe[child]), address, addr_width);
    }else{
      write_register(pgm_read_byte(&child_pipe[child]), address, 1);
	}
    write_register(pgm_read_byte(&child_payload_size[child]),payload_size);

    // Note it would be more efficient to set all of the bits for all open
    // pipes at once.  However, I thought it would make the calling code
    // more simple to do it this way.
    write_register(EN_RXADDR,read_register(EN_RXADDR) | _BV(pgm_read_byte(&child_pipe_enable[child])));

  }
}

/****************************************************************************/

void RF24::closeReadingPipe( uint8_t pipe )
{
  write_register(EN_RXADDR,read_register(EN_RXADDR) & ~_BV(pgm_read_byte(&child_pipe_enable[pipe])));
}

/****************************************************************************/

void RF24::toggle_features(void)
{
    beginTransaction();
	_SPI.transfer( ACTIVATE );
    _SPI.transfer( 0x73 );
	endTransaction();
}

/****************************************************************************/

void RF24::enableDynamicPayloads(void)
{
  // Enable dynamic payload throughout the system

    //toggle_features();
    write_register(FEATURE,read_register(FEATURE) | _BV(EN_DPL) );


  IF_SERIAL_DEBUG(printf("FEATURE=%i\r\n",read_register(FEATURE)));

  // Enable dynamic payload on all pipes
  //
  // Not sure the use case of only having dynamic payload on certain
  // pipes, so the library does not support it.
  write_register(DYNPD,read_register(DYNPD) | _BV(DPL_P5) | _BV(DPL_P4) | _BV(DPL_P3) | _BV(DPL_P2) | _BV(DPL_P1) | _BV(DPL_P0));

  dynamic_payloads_enabled = true;
}

/****************************************************************************/

void RF24::enableAckPayload(void)
{
  //
  // enable ack payload and dynamic payload features
  //

    //toggle_features();
    write_register(FEATURE,read_register(FEATURE) | _BV(EN_ACK_PAY) | _BV(EN_DPL) );

  IF_SERIAL_DEBUG(printf("FEATURE=%i\r\n",read_register(FEATURE)));

  //
  // Enable dynamic payload on pipes 0 & 1
  //

  write_register(DYNPD,read_register(DYNPD) | _BV(DPL_P1) | _BV(DPL_P0));
  dynamic_payloads_enabled = true;
}

/****************************************************************************/

void RF24::enableDynamicAck(void){
  //
  // enable dynamic ack features
  //
    //toggle_features();
    write_register(FEATURE,read_register(FEATURE) | _BV(EN_DYN_ACK) );

  IF_SERIAL_DEBUG(printf("FEATURE=%i\r\n",read_register(FEATURE)));


}

/****************************************************************************/

void RF24::writeAckPayload(uint8_t pipe, const void* buf, uint8_t len)
{
  const uint8_t* current = reinterpret_cast<const uint8_t*>(buf);

  uint8_t data_len = rf24_min(len,32);

  #if defined (RF24_LINUX)
    beginTransaction();
    uint8_t * ptx = spi_txbuff;
    uint8_t size = data_len + 1 ; // Add register value to transmit buffer
	*ptx++ =  W_ACK_PAYLOAD | ( pipe & 0b111 );
    while ( data_len-- ){
      *ptx++ =  *current++;
    }
	
    _SPI.transfern( (char *) spi_txbuff, size);
	endTransaction();
  #else
  beginTransaction();
  _SPI.transfer(W_ACK_PAYLOAD | ( pipe & 0b111 ) );

  while ( data_len-- )
    _SPI.transfer(*current++);
  endTransaction();
  	
  #endif  

}

/****************************************************************************/

bool RF24::isAckPayloadAvailable(void)
{
  return ! (read_register(FIFO_STATUS) & _BV(RX_EMPTY));
}

/****************************************************************************/

bool RF24::isPVariant(void)
{
  return p_variant ;
}

/****************************************************************************/

void RF24::setAutoAck(bool enable)
{
  if ( enable )
    write_register(EN_AA, 0b111111);
  else
    write_register(EN_AA, 0);
}

/****************************************************************************/

void RF24::setAutoAck( uint8_t pipe, bool enable )
{
  if ( pipe <= 6 )
  {
    uint8_t en_aa = read_register( EN_AA ) ;
    if( enable )
    {
      en_aa |= _BV(pipe) ;
    }
    else
    {
      en_aa &= ~_BV(pipe) ;
    }
    write_register( EN_AA, en_aa ) ;
  }
}

/****************************************************************************/

bool RF24::testCarrier(void)
{
  return ( read_register(CD) & 1 );
}

/****************************************************************************/

bool RF24::testRPD(void)
{
  return ( read_register(RPD) & 1 ) ;
}

/****************************************************************************/

void RF24::setPALevel(uint8_t level)
{

  uint8_t setup = read_register(RF_SETUP) & 0b11111000;

  if(level > 3){  						// If invalid level, go to max PA
	  level = (RF24_PA_MAX << 1) + 1;		// +1 to support the SI24R1 chip extra bit
  }else{
	  level = (level << 1) + 1;	 		// Else set level as requested
  }


  write_register( RF_SETUP, setup |= level ) ;	// Write it to the chip
}

/****************************************************************************/

rf24_pa_dbm_e RF24::getPALevel(void)
{
rf24_pa_dbm_e result ;

  uint8_t dr = (read_register(RF_SETUP) & (_BV(RF_PWR_LOW) | _BV(RF_PWR_HIGH))) ;

switch (dr) {
    case 0b00000000:
      result = RF24_PA_MIN;
      break;
    case 0b00000010:
      result = RF24_PA_LOW;
      break;
    case 0b00000100:
      result = RF24_PA_HIGH;
      break;
    case 0b00000110:
      result = RF24_PA_MAX;
      
}

return result;
}

/****************************************************************************/

bool RF24::setDataRate(rf24_datarate_e speed)
{
  bool result = false;
  uint8_t setup = read_register(RF_SETUP) ;

  // HIGH and LOW '00' is 1Mbs - our default
  setup &= ~(_BV(RF_DR_LOW) | _BV(RF_DR_HIGH)) ;
  
  #if defined(__arm__) || defined (RF24_LINUX) || defined (__ARDUINO_X86__)
    txRxDelay=250;
  #else //16Mhz Arduino
    txRxDelay=85;
  #endif
  if( speed == RF24_250KBPS )
  {
    // Must set the RF_DR_LOW to 1; RF_DR_HIGH (used to be RF_DR) is already 0
    // Making it '10'.
    setup |= _BV( RF_DR_LOW ) ;
  #if defined(__arm__) || defined (RF24_LINUX) || defined (__ARDUINO_X86__)
    txRxDelay=450;
  #else //16Mhz Arduino
	txRxDelay=155;
  #endif
  }
  else
  {
    // Set 2Mbs, RF_DR (RF_DR_HIGH) is set 1
    // Making it '01'
    if ( speed == RF24_2MBPS )
    {
      setup |= _BV(RF_DR_HIGH);
      #if defined(__arm__) || defined (RF24_LINUX) || defined (__ARDUINO_X86__)
      txRxDelay=190;
      #else //16Mhz Arduino	  
	  txRxDelay=65;
	  #endif
    }
  }
  write_register(RF_SETUP,setup);

  // Verify our result
  if ( read_register(RF_SETUP) == setup )
  {
    result = true;
  }
  return result;
}

/****************************************************************************/

rf24_datarate_e RF24::getDataRate( void )
{
  rf24_datarate_e result ;
  uint8_t dr = read_register(RF_SETUP) & (_BV(RF_DR_LOW) | _BV(RF_DR_HIGH));

  // switch uses RAM (evil!)
  // Order matters in our case below
  if ( dr == _BV(RF_DR_LOW) )
  {
    // '10' = 250KBPS
    result = RF24_250KBPS ;
  }
  else if ( dr == _BV(RF_DR_HIGH) )
  {
    // '01' = 2MBPS
    result = RF24_2MBPS ;
  }
  else
  {
    // '00' = 1MBPS
    result = RF24_1MBPS ;
  }
  return result ;
}




/******************************************************************************/







rf24_retransmit_delay_e RF24::getRetransmitDelay( void )
{

rf24_retransmit_delay_e result ;
  uint8_t dr = read_register(SETUP_RETR) & (_BV(ARD_LOW) | _BV(ARD_HIGH) | _BV(5) | _BV(6));
switch (dr) {
    case 0b00000000:
      result = RF24_250MICROS;
      break;
    case 0b00010000:
      result = RF24_500MICROS;
      break;
    case 0b00100000:
      result = RF24_750MICROS;
      break;
    case 0b00110000:
      result = RF24_1000MICROS;
      break;
    case 0b01000000:
      result = RF24_1250MICROS;
      break;
    case 0b01010000:
      result = RF24_1500MICROS;
      break;
    case 0b01100000:
      result = RF24_1750MICROS;
      break;
    case 0b01110000:
      result = RF24_2000MICROS;
      break;
    case 0b10000000:
      result = RF24_2250MICROS;
      break;
    case 0b10010000:
      result = RF24_2500MICROS;
      break;
    case 0b10100000:
      result = RF24_2750MICROS;
      break;
    case 0b10110000:
      result = RF24_3000MICROS;
      break;
    case 0b11000000:
      result = RF24_3250MICROS;
      break;
    case 0b11010000:
      result = RF24_3500MICROS;
      break;
    case 0b11100000:
      result = RF24_3750MICROS;
      break;
    case 0b11110000:
      result = RF24_4000MICROS;
}

return result ;

}

rf24_retransmit_count_e RF24::getRetransmitCount( void )
{

rf24_retransmit_count_e result ;
  uint8_t dr = read_register(SETUP_RETR) & (_BV(ARC_LOW) | _BV(ARC_HIGH) | _BV(1) | _BV(2));
switch (dr) {
    case 0b00000000:
      result = RF24_0_C;
      break;
    case 0b00000001:
      result = RF24_1_C;
      break;
    case 0b00000010:
      result = RF24_2_C;
      break;
    case 0b00000011:
      result = RF24_3_C;
      break;
    case 0b00000100:
      result = RF24_4_C;
      break;
    case 0b00000101:
      result = RF24_5_C;
      break;
    case 0b00000110:
      result = RF24_6_C;
      break;
    case 0b00000111:
      result = RF24_7_C;
      break;
    case 0b00001000:
      result = RF24_8_C;
      break;
    case 0b00001001:
      result = RF24_9_C;
      break;
    case 0b00001010:
      result = RF24_10_C;
      break;
    case 0b00001011:
      result = RF24_11_C;
      break;
    case 0b00001100:
      result = RF24_12_C;
      break;
    case 0b00001101:
      result = RF24_13_C;
      break;
    case 0b00001110:
      result = RF24_14_C;
      break;
    case 0b00001111:
      result = RF24_15_C;
}

return result ;
}


rf24_addr_w_e RF24::getAddrWidth( void )
{

 rf24_addr_w_e result ;
  uint8_t dr = read_register(SETUP_AW) & ( _BV(0) | _BV(1));
switch (dr) {
    case 0b00000000:
      result = RF24_ADDR_ERROR;
      break;
    case 0b00000001:
      result = RF24_3_Bytes;
      break;
    case 0b00000010:
      result = RF24_4_Bytes;
      break;
    case 0b00000011:
      result = RF24_5_Bytes;
    
}

return result ;
}





/****************************************************************************/

void RF24::setCRCLength(rf24_crclength_e length)
{
  uint8_t config = read_register(CONFIG) & ~( _BV(CRCO) | _BV(EN_CRC)) ;

  // switch uses RAM (evil!)
  if ( length == RF24_CRC_DISABLED )
  {
    // Do nothing, we turned it off above.
  }
  else if ( length == RF24_CRC_8 )
  {
    config |= _BV(EN_CRC);
  }
  else
  {
    config |= _BV(EN_CRC);
    config |= _BV( CRCO );
  }
  write_register( CONFIG, config ) ;
}

/****************************************************************************/

rf24_crclength_e RF24::getCRCLength(void)
{
  rf24_crclength_e result = RF24_CRC_DISABLED;
  
  uint8_t config = read_register(CONFIG) & ( _BV(CRCO) | _BV(EN_CRC)) ;
  uint8_t AA = read_register(EN_AA);
  
  if ( config & _BV(EN_CRC ) || AA)
  {
    if ( config & _BV(CRCO) )
      result = RF24_CRC_16;
    else
      result = RF24_CRC_8;
  }

  return result;
}

/****************************************************************************/

void RF24::disableCRC( void )
{
  uint8_t disable = read_register(CONFIG) & ~_BV(EN_CRC) ;
  write_register( CONFIG, disable ) ;
}

void RF24::enableCRC( void )
{
  uint8_t enable = read_register(CONFIG) ;
  enable |= _BV(EN_CRC);
  write_register( CONFIG, enable ) ;
}

void RF24::enabletx( void )
{
write_register(CONFIG, ( read_register(CONFIG) ) & ~_BV(PRIM_RX) );
}

void RF24::enablerx( void )
{
write_register(CONFIG, read_register(CONFIG) | _BV(PRIM_RX));
    
}

/****************************************************************************/
void RF24::setRetries(uint8_t delay, uint8_t count)
{
 write_register(SETUP_RETR,(delay&0xf)<<ARD | (count&0xf)<<ARC);
}


//ATTiny support code pulled in from https://github.com/jscrane/RF24

#if defined(__AVR_ATtiny25__) || defined(__AVR_ATtiny45__) || defined(__AVR_ATtiny85__)
// see http://gammon.com.au/spi
#	define DI   0  // D0, pin 5  Data In
#	define DO   1  // D1, pin 6  Data Out (this is *not* MOSI)
#	define USCK 2  // D2, pin 7  Universal Serial Interface clock
#	define SS   3  // D3, pin 2  Slave Select
#elif defined(__AVR_ATtiny24__) || defined(__AVR_ATtiny44__) || defined(__AVR_ATtiny84__)
// these depend on the core used (check pins_arduino.h)
// this is for jeelabs' one (based on google-code core)
#	define DI   4   // PA6
#	define DO   5   // PA5
#	define USCK 6   // PA4
#	define SS   3   // PA7
#elif defined(__AVR_ATtiny2313__) || defined(__AVR_ATtiny4313__)
// these depend on the core used (check pins_arduino.h)
// tested with google-code core
#	define DI   14  // PB5
#	define DO   15  // PB6
#	define USCK 16  // PB7
#	define SS   13  // PB4
#endif

#if defined(RF24_TINY)

void SPIClass::begin() {

  pinMode(USCK, OUTPUT);
  pinMode(DO, OUTPUT);
  pinMode(DI, INPUT);
  USICR = _BV(USIWM0);

}

byte SPIClass::transfer(byte b) {

  USIDR = b;
  USISR = _BV(USIOIF);
  do
    USICR = _BV(USIWM0) | _BV(USICS1) | _BV(USICLK) | _BV(USITC);
  while ((USISR & _BV(USIOIF)) == 0);
  return USIDR;

}

void SPIClass::end() {}
void SPIClass::setDataMode(uint8_t mode){}
void SPIClass::setBitOrder(uint8_t bitOrder){}
void SPIClass::setClockDivider(uint8_t rate){}


#endif
